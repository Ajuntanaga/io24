/*
 * Microsoft OS 1.0 compatible-ID formatting for wineusb
 *
 * Copyright 2026 the Wine project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */

#ifndef __WINE_WINEUSB_MSOS_ID_H
#define __WINE_WINEUSB_MSOS_ID_H

#include <stdbool.h>

#include "windef.h"

#define WINEUSB_MS_OS_10_SOURCE_ID_SIZE 9
#define WINEUSB_MS_OS_10_PNP_ID_SIZE 41

struct wineusb_ms_os_10_pnp_ids
{
    unsigned int count;
    WCHAR ids[2][WINEUSB_MS_OS_10_PNP_ID_SIZE];
};

bool wineusb_ms_os_10_build_pnp_ids(
        const char compatible_id[WINEUSB_MS_OS_10_SOURCE_ID_SIZE],
        const char sub_compatible_id[WINEUSB_MS_OS_10_SOURCE_ID_SIZE],
        struct wineusb_ms_os_10_pnp_ids *ids);

#endif /* __WINE_WINEUSB_MSOS_ID_H */
