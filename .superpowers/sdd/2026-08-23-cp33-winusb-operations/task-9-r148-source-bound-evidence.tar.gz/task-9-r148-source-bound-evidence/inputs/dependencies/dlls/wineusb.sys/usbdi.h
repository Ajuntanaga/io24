/*
 * USB bus interface support for wineusb
 *
 * Copyright 2026 the Wine project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */

#ifndef __WINE_WINEUSB_USBDI_H
#define __WINE_WINEUSB_USBDI_H

#include "ntstatus.h"
#include "windef.h"
#include "winternl.h"
#include "ddk/wdm.h"
#include "ddk/usb.h"

#define WINEUSB_USB_BUSIF_USBDI_VERSION_1 1

typedef void (WINAPI *wineusb_usbdi_get_version)(void *context,
        USBD_VERSION_INFORMATION *version, ULONG *capabilities);
typedef NTSTATUS (WINAPI *wineusb_usbdi_query_bus_time)(void *context,
        ULONG *current_frame);
typedef NTSTATUS (WINAPI *wineusb_usbdi_submit_iso_out_urb)(void *context,
        URB *urb);
typedef NTSTATUS (WINAPI *wineusb_usbdi_query_bus_information)(void *context,
        ULONG level, void *buffer, ULONG *buffer_length, ULONG *actual_length);
typedef BOOLEAN (WINAPI *wineusb_usbdi_is_device_high_speed)(void *context);

struct wineusb_usb_bus_interface_usbdi_v1
{
    USHORT Size;
    USHORT Version;
    void *BusContext;
    PINTERFACE_REFERENCE InterfaceReference;
    PINTERFACE_DEREFERENCE InterfaceDereference;
    wineusb_usbdi_get_version GetUSBDIVersion;
    wineusb_usbdi_query_bus_time QueryBusTime;
    wineusb_usbdi_submit_iso_out_urb SubmitIsoOutUrb;
    wineusb_usbdi_query_bus_information QueryBusInformation;
    wineusb_usbdi_is_device_high_speed IsDeviceHighSpeed;
};

struct wineusb_usbdi_routines
{
    PINTERFACE_REFERENCE InterfaceReference;
    PINTERFACE_DEREFERENCE InterfaceDereference;
    wineusb_usbdi_get_version GetUSBDIVersion;
    wineusb_usbdi_query_bus_time QueryBusTime;
    wineusb_usbdi_submit_iso_out_urb SubmitIsoOutUrb;
    wineusb_usbdi_query_bus_information QueryBusInformation;
    wineusb_usbdi_is_device_high_speed IsDeviceHighSpeed;
};

NTSTATUS wineusb_query_usbdi_interface(const GUID *interface_type, USHORT size,
        USHORT version, INTERFACE *interface, void *context,
        const struct wineusb_usbdi_routines *routines);

#endif /* __WINE_WINEUSB_USBDI_H */
