/*
 * Private WinUSB metadata bus interface for wineusb
 *
 * Copyright 2026 the Wine project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */

#ifndef __WINE_WINEUSB_WINUSB_BUSIF_H
#define __WINE_WINEUSB_WINUSB_BUSIF_H

#include "ntstatus.h"
#include "windef.h"
#include "winternl.h"
#include "ddk/wdm.h"
#include "ddk/usb.h"

#include "msos_id.h"

#define WINEUSB_MS_OS_10_GUID_SIZE 39
#define WINEUSB_MS_OS_10_METADATA_VERSION_1 1
#define WINEUSB_MS_OS_10_METADATA_VERSION_2 2
#define WINEUSB_MS_OS_10_METADATA_INTERFACE_INIT \
    {0xa6523832, 0x2ca5, 0x42ff, {0xaa, 0x70, 0xc7, 0x60, 0xf0, 0x6a, 0x8e, 0x73}}

#define WINEUSB_URB_FUNCTION_CLAIM_TRANSACTION 0x002f
#define WINEUSB_CLAIM_TRANSACTION_COMMIT 1
#define WINEUSB_CLAIM_TRANSACTION_ROLLBACK 2

struct wineusb_claim_transaction_request
{
    struct _URB_HEADER Hdr;
    USBD_CONFIGURATION_HANDLE Transaction;
    ULONG Operation;
    ULONG Reserved;
};

struct wineusb_ms_os_10_metadata_source
{
    char compatible_id[WINEUSB_MS_OS_10_SOURCE_ID_SIZE];
    char sub_compatible_id[WINEUSB_MS_OS_10_SOURCE_ID_SIZE];
    WCHAR device_interface_guid[WINEUSB_MS_OS_10_GUID_SIZE];
    BOOL removed;
};

typedef NTSTATUS (WINAPI *wineusb_get_device_interface_guid)(void *context,
        GUID *guid);

struct wineusb_ms_os_10_metadata_interface_v1
{
    USHORT Size;
    USHORT Version;
    void *BusContext;
    PINTERFACE_REFERENCE InterfaceReference;
    PINTERFACE_DEREFERENCE InterfaceDereference;
    wineusb_get_device_interface_guid GetDeviceInterfaceGuid;
};

typedef NTSTATUS (WINAPI *wineusb_get_device_speed)(void *context, UCHAR *speed);

struct wineusb_ms_os_10_metadata_interface_v2
{
    USHORT Size;
    USHORT Version;
    void *BusContext;
    PINTERFACE_REFERENCE InterfaceReference;
    PINTERFACE_DEREFERENCE InterfaceDereference;
    wineusb_get_device_interface_guid GetDeviceInterfaceGuid;
    wineusb_get_device_speed GetDeviceSpeed;
};

struct wineusb_ms_os_10_metadata_routines
{
    PINTERFACE_REFERENCE InterfaceReference;
    PINTERFACE_DEREFERENCE InterfaceDereference;
    wineusb_get_device_interface_guid GetDeviceInterfaceGuid;
    wineusb_get_device_speed GetDeviceSpeed;
};

NTSTATUS wineusb_ms_os_10_get_device_interface_guid(
        const struct wineusb_ms_os_10_metadata_source *source, GUID *guid);

NTSTATUS wineusb_query_ms_os_10_metadata_interface(const GUID *interface_type,
        USHORT size, USHORT version, INTERFACE *interface, void *context,
        const struct wineusb_ms_os_10_metadata_routines *routines);

#endif /* __WINE_WINEUSB_WINUSB_BUSIF_H */
