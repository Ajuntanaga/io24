/*
 * libusb backend
 *
 * Copyright 2020 Zebediah Figura
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

#if 0
#pragma makedep unix
#endif

#include <stdarg.h>
#include <stdbool.h>
#include <stdlib.h>
#include <libusb.h>
#include <pthread.h>
#include "ntstatus.h"
#include "windef.h"
#include "winternl.h"
#include "ddk/wdm.h"
#include "ddk/usb.h"
#include "wine/winusb.h"
#include "wine/debug.h"
#include "wine/list.h"

#include "unixlib.h"

WINE_DEFAULT_DEBUG_CHANNEL(wineusb);

#define WINEUSB_PIPE_TOKEN_SLOTS 256
#define WINEUSB_PIPE_TOKEN_GENERATION_MAX 0x7fffff
struct wineusb_pipe_token
{
    uint32_t generation;
    uint8_t endpoint, type, interface_number, alternate;
    bool current;
};

/* The token table is deliberately detached from HANDLE representation.  A
 * token is (generation << 9) | (one based slot), never an address. */
struct wineusb_pipe_table
{
    struct wineusb_pipe_token records[WINEUSB_PIPE_TOKEN_SLOTS];
    uint8_t alternates[256];
    uint32_t next_generation;
};

struct unix_device
{
    struct list entry;

    libusb_device_handle *handle;
    struct unix_device *parent;
    unsigned int refcount;
    bool function;
    uint8_t function_interface_count;
    uint16_t configuration_length;
    uint8_t function_root;
    unsigned char function_interfaces[32];
    unsigned char claimed_interfaces[32];
    struct wineusb_pipe_table *pipe_table;
    struct claim_transaction *pending_claim_transaction;
};

struct claim_transaction
{
    USBD_CONFIGURATION_HANDLE token;
    uint8_t interfaces[256];
    uint16_t count;
    struct wineusb_pipe_table *pipe_table;
};

static uintptr_t next_claim_transaction_token;

static bool function_has_interface(bool function, const unsigned char interfaces[32],
        uint8_t interface)
{
    return !function || (interfaces[interface / 8] & (1u << (interface % 8)));
}

static bool device_has_interface(const struct unix_device *device, uint8_t interface)
{
    return function_has_interface(device->function, device->function_interfaces, interface);
}

static void device_add_interface(struct unix_device *device, uint8_t interface)
{
    device->function_interfaces[interface / 8] |= 1u << (interface % 8);
    ++device->function_interface_count;
}

static bool interface_in_set(const unsigned char interfaces[32], uint8_t interface)
{
    return interfaces[interface / 8] & (1u << (interface % 8));
}

static void add_interface_to_set(unsigned char interfaces[32], uint8_t interface)
{
    interfaces[interface / 8] |= 1u << (interface % 8);
}

static void release_claim_transaction(struct unix_device *device,
        struct claim_transaction *transaction)
{
    while (transaction->count)
        libusb_release_interface(device->handle,
                transaction->interfaces[--transaction->count]);
}

static USBD_CONFIGURATION_HANDLE allocate_claim_transaction_token(void)
{
    if (!(++next_claim_transaction_token)) ++next_claim_transaction_token;
    return (void *)next_claim_transaction_token;
}

#define MS_OS_10_STRING_LENGTH 18
#define MS_OS_10_COMPAT_HEADER_LENGTH 16
#define MS_OS_10_COMPAT_FUNCTION_LENGTH 24
#define MS_OS_10_PROPERTIES_HEADER_LENGTH 10
#define MS_OS_10_MAX_DESCRIPTOR_LENGTH 4096
#define MS_OS_10_TIMEOUT_MS 1000

struct ms_os_10_function_metadata
{
    uint8_t vendor_code;
    char compatible_id[WINEUSB_MS_OS_10_ID_SIZE];
    char sub_compatible_id[WINEUSB_MS_OS_10_ID_SIZE];
    WCHAR device_interface_guid[WINEUSB_MS_OS_10_GUID_SIZE];
};

static uint16_t get_u16(const unsigned char *buffer)
{
    return buffer[0] | ((uint16_t)buffer[1] << 8);
}

static uint32_t get_u32(const unsigned char *buffer)
{
    return buffer[0] | ((uint32_t)buffer[1] << 8) |
            ((uint32_t)buffer[2] << 16) | ((uint32_t)buffer[3] << 24);
}

static bool bytes_are_zero(const unsigned char *buffer, size_t length)
{
    size_t i;

    for (i = 0; i < length; ++i)
        if (buffer[i]) return false;
    return true;
}

static bool ms_os_10_id_character(unsigned char value)
{
    return (value >= 'A' && value <= 'Z') ||
            (value >= '0' && value <= '9') || value == '_';
}

static bool parse_ms_os_10_id(const unsigned char source[8],
        char destination[WINEUSB_MS_OS_10_ID_SIZE])
{
    bool terminated = false;
    size_t i, length = 0;

    memset(destination, 0, WINEUSB_MS_OS_10_ID_SIZE);
    for (i = 0; i < 8; ++i)
    {
        if (!source[i])
        {
            terminated = true;
            continue;
        }
        if (terminated || !ms_os_10_id_character(source[i])) return false;
        destination[length++] = source[i];
    }
    return true;
}

static bool parse_ms_os_10_string(const unsigned char *buffer, size_t length,
        uint8_t *vendor_code)
{
    static const unsigned char signature[14] =
        {'M', 0, 'S', 0, 'F', 0, 'T', 0, '1', 0, '0', 0, '0', 0};

    if (length != MS_OS_10_STRING_LENGTH || buffer[0] != MS_OS_10_STRING_LENGTH ||
            buffer[1] != LIBUSB_DT_STRING || memcmp(buffer + 2, signature, sizeof(signature)) ||
            buffer[17])
        return false;
    *vendor_code = buffer[16];
    return true;
}

static bool validate_ms_os_10_compatible_header(const unsigned char *header,
        size_t *descriptor_length)
{
    size_t expected_length;

    *descriptor_length = get_u32(header);
    expected_length = MS_OS_10_COMPAT_HEADER_LENGTH +
            (size_t)header[8] * MS_OS_10_COMPAT_FUNCTION_LENGTH;
    return get_u16(header + 4) == 0x0100 && get_u16(header + 6) == 0x0004 &&
            bytes_are_zero(header + 9, 7) &&
            *descriptor_length == expected_length &&
            *descriptor_length <= MS_OS_10_MAX_DESCRIPTOR_LENGTH;
}

static bool parse_ms_os_10_compatible_ids(const unsigned char *buffer, size_t length,
        struct ms_os_10_function_metadata functions[256])
{
    bool used_interfaces[256] = {0};
    size_t descriptor_length, offset;
    unsigned int i;

    memset(functions, 0, 256 * sizeof(*functions));
    if (length < MS_OS_10_COMPAT_HEADER_LENGTH ||
            !validate_ms_os_10_compatible_header(buffer, &descriptor_length) ||
            descriptor_length != length)
        return false;

    for (i = 0, offset = MS_OS_10_COMPAT_HEADER_LENGTH; i < buffer[8];
            ++i, offset += MS_OS_10_COMPAT_FUNCTION_LENGTH)
    {
        const unsigned char *section = buffer + offset;
        unsigned int interface = section[0];

        if (section[1] != 1 || used_interfaces[interface] ||
                !bytes_are_zero(section + 18, 6) ||
                !parse_ms_os_10_id(section + 2, functions[interface].compatible_id) ||
                !parse_ms_os_10_id(section + 10, functions[interface].sub_compatible_id))
            return false;
        used_interfaces[interface] = true;
    }
    return true;
}

static bool utf16le_equals_ascii(const unsigned char *buffer, size_t length,
        const char *ascii)
{
    size_t i, expected_length = 2 * (strlen(ascii) + 1);

    if (length != expected_length) return false;
    for (i = 0; i < expected_length / 2; ++i)
        if (buffer[2 * i] != (unsigned char)ascii[i] || buffer[2 * i + 1]) return false;
    return true;
}

static bool guid_character(unsigned int index, unsigned char value)
{
    if (index == 0) return value == '{';
    if (index == 9 || index == 14 || index == 19 || index == 24) return value == '-';
    if (index == 37) return value == '}';
    return (value >= '0' && value <= '9') ||
            (value >= 'a' && value <= 'f') || (value >= 'A' && value <= 'F');
}

static bool parse_device_interface_guid(const unsigned char *buffer, size_t length,
        WCHAR guid[WINEUSB_MS_OS_10_GUID_SIZE])
{
    WCHAR parsed[WINEUSB_MS_OS_10_GUID_SIZE];
    unsigned int i;

    if (length != 2 * WINEUSB_MS_OS_10_GUID_SIZE) return false;
    for (i = 0; i < WINEUSB_MS_OS_10_GUID_SIZE; ++i)
    {
        if (buffer[2 * i + 1]) return false;
        parsed[i] = buffer[2 * i];
        if (i + 1 == WINEUSB_MS_OS_10_GUID_SIZE)
        {
            if (parsed[i]) return false;
        }
        else if (!guid_character(i, parsed[i])) return false;
    }
    memcpy(guid, parsed, sizeof(parsed));
    return true;
}

static bool parse_ms_os_10_properties(const unsigned char *buffer, size_t length,
        WCHAR guid[WINEUSB_MS_OS_10_GUID_SIZE])
{
    WCHAR parsed_guid[WINEUSB_MS_OS_10_GUID_SIZE] = {0};
    bool found_guid = false;
    size_t offset = MS_OS_10_PROPERTIES_HEADER_LENGTH;
    unsigned int i;

    memset(guid, 0, WINEUSB_MS_OS_10_GUID_SIZE * sizeof(*guid));
    if (length < MS_OS_10_PROPERTIES_HEADER_LENGTH || get_u32(buffer) != length ||
            get_u16(buffer + 4) != 0x0100 || get_u16(buffer + 6) != 0x0005)
        return false;

    for (i = 0; i < get_u16(buffer + 8); ++i)
    {
        const unsigned char *section;
        size_t section_length, name_length, data_length;

        if (length - offset < 14) return false;
        section = buffer + offset;
        section_length = get_u32(section);
        name_length = get_u16(section + 8);
        if (section_length < 14 || section_length > length - offset ||
                name_length < 2 || name_length & 1 || 14 + name_length > section_length)
            return false;
        data_length = get_u32(section + 10 + name_length);
        if (data_length != section_length - 14 - name_length) return false;

        if (utf16le_equals_ascii(section + 10, name_length, "DeviceInterfaceGUID"))
        {
            if (found_guid || get_u32(section + 4) != 1 ||
                    !parse_device_interface_guid(section + 14 + name_length,
                            data_length, parsed_guid))
                return false;
            found_guid = true;
        }
        offset += section_length;
    }
    if (offset != length) return false;
    if (found_guid) memcpy(guid, parsed_guid, sizeof(parsed_guid));
    return true;
}

static int get_ms_os_10_descriptor(libusb_device_handle *handle, uint8_t request_type,
        uint8_t request, uint16_t value, uint16_t index, unsigned char *buffer,
        uint16_t length)
{
    return libusb_control_transfer(handle, request_type, request, value, index,
            buffer, length, MS_OS_10_TIMEOUT_MS);
}

static bool get_ms_os_10_compatible_ids(libusb_device_handle *handle,
        uint8_t vendor_code, struct ms_os_10_function_metadata functions[256])
{
    unsigned char header[MS_OS_10_COMPAT_HEADER_LENGTH], *descriptor;
    size_t descriptor_length;
    bool ret;

    if (get_ms_os_10_descriptor(handle, 0xc0, vendor_code, 0, 4, header,
            sizeof(header)) != sizeof(header) ||
            !validate_ms_os_10_compatible_header(header, &descriptor_length))
        return false;
    if (descriptor_length == sizeof(header))
        return parse_ms_os_10_compatible_ids(header, sizeof(header), functions);
    if (!(descriptor = malloc(descriptor_length))) return false;
    if (get_ms_os_10_descriptor(handle, 0xc0, vendor_code, 0, 4, descriptor,
            descriptor_length) != descriptor_length)
        ret = false;
    else
        ret = parse_ms_os_10_compatible_ids(descriptor, descriptor_length, functions);
    free(descriptor);
    return ret;
}

static bool get_ms_os_10_properties(libusb_device_handle *handle, uint8_t vendor_code,
        uint8_t interface, WCHAR guid[WINEUSB_MS_OS_10_GUID_SIZE])
{
    unsigned char header[MS_OS_10_PROPERTIES_HEADER_LENGTH], *descriptor;
    size_t descriptor_length;
    bool ret;

    if (get_ms_os_10_descriptor(handle, 0xc1, vendor_code, interface << 8, 5,
            header, sizeof(header)) != sizeof(header))
        return false;
    descriptor_length = get_u32(header);
    if (get_u16(header + 4) != 0x0100 || get_u16(header + 6) != 0x0005 ||
            descriptor_length < sizeof(header) ||
            descriptor_length > MS_OS_10_MAX_DESCRIPTOR_LENGTH)
        return false;
    if (descriptor_length == sizeof(header))
        return parse_ms_os_10_properties(header, sizeof(header), guid);
    if (!(descriptor = malloc(descriptor_length))) return false;
    if (get_ms_os_10_descriptor(handle, 0xc1, vendor_code, interface << 8, 5,
            descriptor, descriptor_length) != descriptor_length)
        ret = false;
    else
        ret = parse_ms_os_10_properties(descriptor, descriptor_length, guid);
    free(descriptor);
    return ret;
}

static void discover_ms_os_10(libusb_device_handle *handle,
        struct ms_os_10_function_metadata functions[256])
{
    unsigned char string[MS_OS_10_STRING_LENGTH];
    uint8_t vendor_code;
    unsigned int i;

    memset(functions, 0, 256 * sizeof(*functions));
    if (get_ms_os_10_descriptor(handle, 0x80, LIBUSB_REQUEST_GET_DESCRIPTOR,
            0x03ee, 0, string, sizeof(string)) != sizeof(string) ||
            !parse_ms_os_10_string(string, sizeof(string), &vendor_code))
        return;
    if (!get_ms_os_10_compatible_ids(handle, vendor_code, functions))
    {
        memset(functions, 0, 256 * sizeof(*functions));
        return;
    }

    for (i = 0; i < 256; ++i)
    {
        if (!functions[i].compatible_id[0]) continue;
        functions[i].vendor_code = vendor_code;
    }
}

static bool assign_function_range(uint8_t roots[256], const bool present[256],
        bool grouped[256], uint8_t root, uint8_t count)
{
    unsigned int i;

    if (count < 2 || (unsigned int)root + count > 256)
        return false;
    for (i = root; i < (unsigned int)root + count; ++i)
        if (!present[i] || grouped[i]) return false;
    for (i = root; i < (unsigned int)root + count; ++i)
    {
        roots[i] = root;
        grouped[i] = true;
    }
    return true;
}

static bool assign_audio_function(uint8_t roots[256], const bool present[256],
        bool grouped[256], uint8_t root, const unsigned char *interfaces,
        uint8_t interface_count)
{
    unsigned int i;

    if (!interface_count || !present[root] || grouped[root]) return false;
    for (i = 0; i < interface_count; ++i)
        if (!present[interfaces[i]] || grouped[interfaces[i]]) return false;

    roots[root] = root;
    grouped[root] = true;
    for (i = 0; i < interface_count; ++i)
    {
        roots[interfaces[i]] = root;
        grouped[interfaces[i]] = true;
    }
    return true;
}

static bool build_function_roots(libusb_device *device,
        const struct libusb_config_descriptor *config, uint8_t roots[256],
        bool present[256])
{
    struct libusb_interface_association_descriptor_array *associations = NULL;
    bool grouped[256] = {0}, found = false;
    unsigned int i, j;
    int ret;

    for (i = 0; i < 256; ++i) roots[i] = i;
    for (i = 0; i < config->bNumInterfaces; ++i)
    {
        const struct libusb_interface *interface = &config->interface[i];

        if (interface->num_altsetting > 0)
            present[interface->altsetting[0].bInterfaceNumber] = true;
    }

    ret = libusb_get_active_interface_association_descriptors(device, &associations);
    if (!ret)
    {
        for (i = 0; i < (unsigned int)associations->length; ++i)
        {
            const struct libusb_interface_association_descriptor *association =
                    &associations->iad[i];

            if (assign_function_range(roots, present, grouped,
                    association->bFirstInterface, association->bInterfaceCount))
                found = true;
        }
        libusb_free_interface_association_descriptors(associations);
    }
    else if (ret != LIBUSB_ERROR_NOT_FOUND)
    {
        WARN("Failed to get interface associations: %s\n", libusb_strerror(ret));
    }

    for (i = 0; i < config->bNumInterfaces; ++i)
    {
        const struct libusb_interface *interface = &config->interface[i];

        for (j = 0; j < (unsigned int)interface->num_altsetting; ++j)
        {
            const struct libusb_interface_descriptor *descriptor = &interface->altsetting[j];
            const unsigned char *cursor = descriptor->extra;
            size_t remaining = descriptor->extra_length;

            if (descriptor->bInterfaceClass != LIBUSB_CLASS_AUDIO ||
                    descriptor->bInterfaceSubClass != 1 || descriptor->bInterfaceProtocol != 0)
                continue;

            while (remaining >= 2)
            {
                uint8_t length = cursor[0];

                if (length < 2 || length > remaining) break;
                if (cursor[1] == 0x24 && length >= 8 && cursor[2] == 1 &&
                        length >= 8u + cursor[7] &&
                        assign_audio_function(roots, present, grouped,
                                descriptor->bInterfaceNumber, cursor + 8, cursor[7]))
                    found = true;
                cursor += length;
                remaining -= length;
            }
        }
    }

    return found;
}

static libusb_hotplug_callback_handle hotplug_cb_handle;

static volatile bool thread_shutdown;

static struct usb_event *usb_events;
static size_t usb_event_count, usb_events_capacity;

static pthread_mutex_t device_mutex = PTHREAD_MUTEX_INITIALIZER;

static struct list device_list = LIST_INIT(device_list);

static bool array_reserve(void **elements, size_t *capacity, size_t count, size_t size)
{
    unsigned int new_capacity, max_capacity;
    void *new_elements;

    if (count <= *capacity)
        return true;

    max_capacity = ~(size_t)0 / size;
    if (count > max_capacity)
        return false;

    new_capacity = max(4, *capacity);
    while (new_capacity < count && new_capacity <= max_capacity / 2)
        new_capacity *= 2;
    if (new_capacity < count)
        new_capacity = max_capacity;

    if (!(new_elements = realloc(*elements, new_capacity * size)))
        return false;

    *elements = new_elements;
    *capacity = new_capacity;

    return true;
}

static void queue_event(const struct usb_event *event)
{
    if (array_reserve((void **)&usb_events, &usb_events_capacity, usb_event_count + 1, sizeof(*usb_events)))
        usb_events[usb_event_count++] = *event;
    else
        ERR("Failed to queue event.\n");
}

static bool get_event(struct usb_event *event)
{
    if (!usb_event_count) return false;

    *event = usb_events[0];
    if (--usb_event_count)
        memmove(usb_events, usb_events + 1, usb_event_count * sizeof(*usb_events));

    return true;
}

static void set_event_ms_os_10(struct usb_event *event, libusb_device_handle *handle,
        uint8_t interface, struct ms_os_10_function_metadata *metadata)
{
    if (metadata->compatible_id[0])
    {
        get_ms_os_10_properties(handle, metadata->vendor_code, interface,
                metadata->device_interface_guid);
        TRACE("Microsoft OS 1.0 interface %u compatible ID %s, sub-compatible ID %s.\n",
                interface, metadata->compatible_id, metadata->sub_compatible_id);
    }
    event->u.added_device.ms_vendor_code = metadata->vendor_code;
    memcpy(event->u.added_device.ms_compatible_id, metadata->compatible_id,
            sizeof(event->u.added_device.ms_compatible_id));
    memcpy(event->u.added_device.ms_sub_compatible_id, metadata->sub_compatible_id,
            sizeof(event->u.added_device.ms_sub_compatible_id));
    memcpy(event->u.added_device.device_interface_guid, metadata->device_interface_guid,
            sizeof(event->u.added_device.device_interface_guid));
}

static void add_usb_device(libusb_device *libusb_device)
{
    struct libusb_config_descriptor *config_desc;
    struct libusb_device_descriptor device_desc;
    struct ms_os_10_function_metadata ms_os_10_functions[256];
    struct unix_device *unix_device;
    struct usb_event usb_event;
    int ret;

    libusb_get_device_descriptor(libusb_device, &device_desc);

    TRACE("Adding new device %p, vendor %04x, product %04x.\n", libusb_device,
            device_desc.idVendor, device_desc.idProduct);

    if (!(unix_device = calloc(1, sizeof(*unix_device))))
        return;

    if ((ret = libusb_open(libusb_device, &unix_device->handle)))
    {
        WARN("Failed to open device: %s\n", libusb_strerror(ret));
        free(unix_device);
        return;
    }
    unix_device->refcount = 1;
    discover_ms_os_10(unix_device->handle, ms_os_10_functions);

    pthread_mutex_lock(&device_mutex);
    list_add_tail(&device_list, &unix_device->entry);
    pthread_mutex_unlock(&device_mutex);

    memset(&usb_event, 0, sizeof(usb_event));
    usb_event.type = USB_EVENT_ADD_DEVICE;
    usb_event.u.added_device.device = unix_device;
    usb_event.u.added_device.vendor = device_desc.idVendor;
    usb_event.u.added_device.product = device_desc.idProduct;
    usb_event.u.added_device.revision = device_desc.bcdDevice;
    usb_event.u.added_device.usbver = device_desc.bcdUSB;
    usb_event.u.added_device.class = device_desc.bDeviceClass;
    usb_event.u.added_device.subclass = device_desc.bDeviceSubClass;
    usb_event.u.added_device.protocol = device_desc.bDeviceProtocol;
    usb_event.u.added_device.busnum = libusb_get_bus_number(libusb_device);
    usb_event.u.added_device.portnum = libusb_get_port_number(libusb_device);
    usb_event.u.added_device.interface = false;
    usb_event.u.added_device.high_speed =
            libusb_get_device_speed(libusb_device) >= LIBUSB_SPEED_HIGH;
    usb_event.u.added_device.interface_index = -1;

    if (!(ret = libusb_get_active_config_descriptor(libusb_device, &config_desc)))
    {
        const struct libusb_interface *interface;
        const struct libusb_interface_descriptor *iface_desc;
        uint8_t function_roots[256];
        bool present[256] = {0};
        bool function_scoped = false;

        if (config_desc->bNumInterfaces == 1)
        {
            interface = &config_desc->interface[0];
            if (interface->num_altsetting != 1)
                FIXME("Interface 0 has %u alternate settings; using the first one.\n",
                        interface->num_altsetting);
            iface_desc = &interface->altsetting[0];

            usb_event.u.added_device.class = iface_desc->bInterfaceClass;
            usb_event.u.added_device.subclass = iface_desc->bInterfaceSubClass;
            usb_event.u.added_device.protocol = iface_desc->bInterfaceProtocol;
            usb_event.u.added_device.interface_index = iface_desc->bInterfaceNumber;
            set_event_ms_os_10(&usb_event, unix_device->handle,
                    iface_desc->bInterfaceNumber,
                    &ms_os_10_functions[iface_desc->bInterfaceNumber]);
        }
        queue_event(&usb_event);

        /* Create new devices for functions of composite devices.
         *
         * On Windows this is the job of usbccgp.sys, a separate driver that
         * layers on top of the base USB driver. While we could take this
         * approach as well, implementing usbccgp is a lot more work, whereas
         * interface support is effectively built into libusb.
         */
        if (config_desc->bNumInterfaces > 1)
        {
            uint8_t i;

            if (device_desc.bNumConfigurations == 1)
                function_scoped = build_function_roots(libusb_device,
                        config_desc, function_roots, present);

            for (i = 0; i < config_desc->bNumInterfaces; ++i)
            {
                struct unix_device *unix_iface;
                unsigned int number;

                interface = &config_desc->interface[i];
                if (interface->num_altsetting <= 0) continue;
                if (interface->num_altsetting != 1)
                    FIXME("Interface %u has %u alternate settings; using the first one.\n",
                            interface->altsetting[0].bInterfaceNumber, interface->num_altsetting);
                iface_desc = &interface->altsetting[0];
                if (function_scoped && function_roots[iface_desc->bInterfaceNumber] !=
                        iface_desc->bInterfaceNumber)
                    continue;

                if (!(unix_iface = calloc(1, sizeof(*unix_iface))))
                    return;

                ++unix_device->refcount;
                unix_iface->refcount = 1;
                unix_iface->handle = unix_device->handle;
                unix_iface->parent = unix_device;
                unix_iface->function = function_scoped;
                unix_iface->configuration_length = config_desc->wTotalLength;
                unix_iface->function_root = iface_desc->bInterfaceNumber;
                if (function_scoped)
                {
                    for (number = 0; number < 256; ++number)
                        if (present[number] && function_roots[number] == iface_desc->bInterfaceNumber)
                            device_add_interface(unix_iface, number);
                }
                pthread_mutex_lock(&device_mutex);
                list_add_tail(&device_list, &unix_iface->entry);
                pthread_mutex_unlock(&device_mutex);

                usb_event.u.added_device.device = unix_iface;
                usb_event.u.added_device.class = iface_desc->bInterfaceClass;
                usb_event.u.added_device.subclass = iface_desc->bInterfaceSubClass;
                usb_event.u.added_device.protocol = iface_desc->bInterfaceProtocol;
                usb_event.u.added_device.interface = true;
                usb_event.u.added_device.interface_index = iface_desc->bInterfaceNumber;
                set_event_ms_os_10(&usb_event, unix_device->handle,
                        iface_desc->bInterfaceNumber,
                        &ms_os_10_functions[iface_desc->bInterfaceNumber]);
                FIXME("IO24_FUNCTION_SCOPE event=child root=%u scoped=%u interfaces=%u "
                        "configuration_length=%u.\n", iface_desc->bInterfaceNumber,
                        function_scoped, unix_iface->function_interface_count,
                        unix_iface->configuration_length);
                queue_event(&usb_event);
            }
        }
        libusb_free_config_descriptor(config_desc);
    }
    else
    {
        queue_event(&usb_event);

        ERR("Failed to get configuration descriptor: %s\n", libusb_strerror(ret));
    }
}

static void remove_usb_device(libusb_device *libusb_device)
{
    struct unix_device *unix_device;
    struct usb_event usb_event;

    TRACE("Removing device %p.\n", libusb_device);

    LIST_FOR_EACH_ENTRY(unix_device, &device_list, struct unix_device, entry)
    {
        if (libusb_get_device(unix_device->handle) == libusb_device)
        {
            usb_event.type = USB_EVENT_REMOVE_DEVICE;
            usb_event.u.removed_device = unix_device;
            queue_event(&usb_event);
        }
    }
}

static int LIBUSB_CALL hotplug_cb(libusb_context *context, libusb_device *device,
        libusb_hotplug_event event, void *user_data)
{
    if (event == LIBUSB_HOTPLUG_EVENT_DEVICE_ARRIVED)
        add_usb_device(device);
    else
        remove_usb_device(device);

    return 0;
}

static NTSTATUS usb_main_loop(void *args)
{
    const struct usb_main_loop_params *params = args;
    int ret;

    while (!thread_shutdown)
    {
        if (get_event(params->event)) return STATUS_PENDING;

        if ((ret = libusb_handle_events(NULL)))
            ERR("Error handling events: %s\n", libusb_strerror(ret));
    }

    libusb_exit(NULL);
    free(usb_events);
    usb_events = NULL;
    usb_event_count = usb_events_capacity = 0;
    thread_shutdown = false;

    TRACE("USB main loop exiting.\n");
    return STATUS_SUCCESS;
}

static NTSTATUS usb_init(void *args)
{
    int ret;

    if ((ret = libusb_init(NULL)))
    {
        ERR("Failed to initialize libusb: %s\n", libusb_strerror(ret));
        return STATUS_UNSUCCESSFUL;
    }

    if ((ret = libusb_hotplug_register_callback(NULL,
            LIBUSB_HOTPLUG_EVENT_DEVICE_ARRIVED | LIBUSB_HOTPLUG_EVENT_DEVICE_LEFT,
            LIBUSB_HOTPLUG_ENUMERATE, LIBUSB_HOTPLUG_MATCH_ANY, LIBUSB_HOTPLUG_MATCH_ANY,
            LIBUSB_HOTPLUG_MATCH_ANY, hotplug_cb, NULL, &hotplug_cb_handle)))
    {
        ERR("Failed to register callback: %s\n", libusb_strerror(ret));
        libusb_exit(NULL);
        return STATUS_UNSUCCESSFUL;
    }

    return STATUS_SUCCESS;
}

static NTSTATUS usb_exit(void *args)
{
    libusb_hotplug_deregister_callback(NULL, hotplug_cb_handle);
    thread_shutdown = true;
    libusb_interrupt_event_handler(NULL);

    return STATUS_SUCCESS;
}

static NTSTATUS usbd_status_from_libusb(enum libusb_transfer_status status)
{
    switch (status)
    {
        case LIBUSB_TRANSFER_CANCELLED:
            return USBD_STATUS_CANCELED;
        case LIBUSB_TRANSFER_COMPLETED:
            return USBD_STATUS_SUCCESS;
        case LIBUSB_TRANSFER_NO_DEVICE:
            return USBD_STATUS_DEVICE_GONE;
        case LIBUSB_TRANSFER_STALL:
            return USBD_STATUS_ENDPOINT_HALTED;
        case LIBUSB_TRANSFER_TIMED_OUT:
            return USBD_STATUS_TIMEOUT;
        default:
            FIXME("Unhandled status %#x.\n", status);
        case LIBUSB_TRANSFER_ERROR:
            return USBD_STATUS_REQUEST_FAILED;
    }
}

struct transfer_ctx
{
    IRP *irp;
    void *transfer_buffer;
    size_t transfer_buffer_length;
    bool function;
    uint8_t function_interface_count;
    uint8_t function_root;
    unsigned char function_interfaces[32];
};

static void append_projected_descriptor(unsigned char *output, size_t output_capacity,
        size_t *output_length, const unsigned char *descriptor, size_t descriptor_length)
{
    size_t copy_length = 0;

    if (*output_length < output_capacity)
    {
        copy_length = output_capacity - *output_length;
        if (copy_length > descriptor_length) copy_length = descriptor_length;
        memcpy(output + *output_length, descriptor, copy_length);
    }
    *output_length += descriptor_length;
}

static bool project_configuration_descriptor(const struct transfer_ctx *transfer_ctx,
        const unsigned char *input, size_t input_length, unsigned char *output,
        size_t output_capacity, size_t *returned_length)
{
    size_t offset, projected_length = 0, total_length;
    bool have_interface = false, include_interface = false;

    if (input_length < LIBUSB_DT_CONFIG_SIZE || input[0] < LIBUSB_DT_CONFIG_SIZE ||
            input[0] > input_length || input[1] != LIBUSB_DT_CONFIG)
        return false;
    total_length = input[2] | ((size_t)input[3] << 8);
    if (total_length < input[0] || total_length > input_length)
        return false;

    append_projected_descriptor(output, output_capacity, &projected_length, input, input[0]);
    offset = input[0];
    while (offset < total_length)
    {
        const unsigned char *descriptor = input + offset;
        uint8_t length, type;
        bool include;

        if (total_length - offset < 2) return false;
        length = descriptor[0];
        type = descriptor[1];
        if (length < 2 || length > total_length - offset) return false;

        if (type == LIBUSB_DT_INTERFACE_ASSOCIATION)
        {
            unsigned int i;

            if (length < LIBUSB_DT_INTERFACE_ASSOCIATION_SIZE) return false;
            include = false;
            for (i = descriptor[2]; i < (unsigned int)descriptor[2] + descriptor[3] && i < 256; ++i)
                if (function_has_interface(transfer_ctx->function,
                        transfer_ctx->function_interfaces, i)) include = true;
            have_interface = false;
            include_interface = false;
        }
        else if (type == LIBUSB_DT_INTERFACE)
        {
            if (length < LIBUSB_DT_INTERFACE_SIZE) return false;
            include_interface = function_has_interface(transfer_ctx->function,
                    transfer_ctx->function_interfaces, descriptor[2]);
            have_interface = true;
            include = include_interface;
        }
        else
        {
            include = !have_interface || include_interface;
        }

        if (include)
            append_projected_descriptor(output, output_capacity, &projected_length,
                    descriptor, length);
        offset += length;
    }

    if (projected_length > UINT16_MAX) return false;
    if (output_capacity > 2) output[2] = projected_length;
    if (output_capacity > 3) output[3] = projected_length >> 8;
    if (output_capacity > 4) output[4] = transfer_ctx->function_interface_count;
    *returned_length = projected_length < output_capacity ? projected_length : output_capacity;
    return true;
}

static void LIBUSB_CALL transfer_cb(struct libusb_transfer *transfer)
{
    struct transfer_ctx *transfer_ctx = transfer->user_data;
    IRP *irp = transfer_ctx->irp;
    URB *urb = IoGetCurrentIrpStackLocation(irp)->Parameters.Others.Argument1;
    unsigned char *transfer_buffer = transfer_ctx->transfer_buffer;
    struct usb_event event;

    TRACE("Completing IRP %p, status %#x.\n", irp, transfer->status);

    urb->UrbHeader.Status = usbd_status_from_libusb(transfer->status);
    if (transfer->status != LIBUSB_TRANSFER_COMPLETED &&
            urb->UrbHeader.Function == URB_FUNCTION_CONTROL_TRANSFER)
        urb->UrbControlTransfer.TransferBufferLength = 0;
    if (transfer->status == LIBUSB_TRANSFER_COMPLETED)
    {
        switch (urb->UrbHeader.Function)
        {
            case URB_FUNCTION_BULK_OR_INTERRUPT_TRANSFER:
                urb->UrbBulkOrInterruptTransfer.TransferBufferLength = transfer->actual_length;
                break;

            case URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE:
            {
                struct _URB_CONTROL_DESCRIPTOR_REQUEST *req = &urb->UrbControlDescriptorRequest;
                size_t returned_length;

                if (transfer_ctx->function && req->DescriptorType == LIBUSB_DT_CONFIG)
                {
                    if (!project_configuration_descriptor(transfer_ctx,
                            libusb_control_transfer_get_data(transfer), transfer->actual_length,
                            transfer_buffer, transfer_ctx->transfer_buffer_length, &returned_length))
                    {
                        req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                        req->TransferBufferLength = 0;
                        break;
                    }
                    req->TransferBufferLength = returned_length;
                    FIXME("IO24_FUNCTION_SCOPE event=descriptor root=%u root_interfaces=%u "
                            "physical_length=%d returned_length=%u.\n",
                            transfer_ctx->function_root,
                            transfer_ctx->function_interface_count,
                            transfer->actual_length, req->TransferBufferLength);
                }
                else
                {
                    returned_length = transfer->actual_length;
                    if (returned_length > transfer_ctx->transfer_buffer_length)
                        returned_length = transfer_ctx->transfer_buffer_length;
                    req->TransferBufferLength = returned_length;
                    memcpy(transfer_buffer, libusb_control_transfer_get_data(transfer), returned_length);
                }
                break;
            }

            case URB_FUNCTION_VENDOR_DEVICE:
            case URB_FUNCTION_VENDOR_INTERFACE:
            case URB_FUNCTION_VENDOR_ENDPOINT:
            {
                struct _URB_CONTROL_VENDOR_OR_CLASS_REQUEST *req = &urb->UrbControlVendorClassRequest;
                req->TransferBufferLength = transfer->actual_length;
                if (req->TransferFlags & USBD_TRANSFER_DIRECTION_IN)
                    memcpy(transfer_buffer, libusb_control_transfer_get_data(transfer), transfer->actual_length);
                break;
            }

            case URB_FUNCTION_CONTROL_TRANSFER:
            {
                struct _URB_CONTROL_TRANSFER *req = &urb->UrbControlTransfer;
                size_t returned_length;

                if (req->SetupPacket[0] & LIBUSB_ENDPOINT_IN)
                {
                    returned_length = transfer->actual_length;
                    if (returned_length > transfer_ctx->transfer_buffer_length)
                        returned_length = transfer_ctx->transfer_buffer_length;
                    req->TransferBufferLength = returned_length;
                    memcpy(transfer_buffer, libusb_control_transfer_get_data(transfer), returned_length);
                }
                else
                {
                    returned_length = transfer->actual_length;
                    if (returned_length > transfer_ctx->transfer_buffer_length)
                        returned_length = transfer_ctx->transfer_buffer_length;
                    req->TransferBufferLength = returned_length;
                }
                break;
            }

            default:
                ERR("Unexpected function %#x.\n", urb->UrbHeader.Function);
        }
    }

    irp->Tail.Overlay.DriverContext[0] = NULL;
    free(transfer_ctx);

    event.type = USB_EVENT_TRANSFER_COMPLETE;
    event.u.completed_irp = irp;
    queue_event(&event);
}

static HANDLE issue_pipe_token(struct wineusb_pipe_table *table, unsigned char endpoint,
        USBD_PIPE_TYPE type, unsigned char interface_number, unsigned char alternate,
        uint32_t generation)
{
    unsigned int slot;
    if (!generation || generation > WINEUSB_PIPE_TOKEN_GENERATION_MAX) return NULL;
    for (slot = 0; slot < WINEUSB_PIPE_TOKEN_SLOTS; ++slot)
        if (!table->records[slot].current) break;
    if (slot == WINEUSB_PIPE_TOKEN_SLOTS) return NULL;
    table->records[slot] = (struct wineusb_pipe_token){generation, endpoint, type, interface_number, alternate, true};
    return (HANDLE)(uintptr_t)((generation << 9) | (slot + 1));
}

static struct wineusb_pipe_token *lookup_pipe_token(struct unix_device *device, HANDLE handle)
{
    uintptr_t value = (uintptr_t)handle; unsigned int slot = (value & 0x1ff) - 1;
    uint32_t generation = value >> 9;
    if (!(value & 0x1ff) || value > UINT32_MAX || slot >= WINEUSB_PIPE_TOKEN_SLOTS || !generation || !device->pipe_table ||
            !device->pipe_table->records[slot].current || device->pipe_table->records[slot].generation != generation) return NULL;
    return &device->pipe_table->records[slot];
}

static bool pipe_token_is_current(const struct unix_device *device,
        const struct wineusb_pipe_token *pipe)
{
    struct libusb_config_descriptor *config;
    bool found = false;
    unsigned int i, j, k;
    if (!pipe || !device->handle) return false;
    if (libusb_get_active_config_descriptor(libusb_get_device(device->handle), &config)) return false;
    {
        for (i = 0; i < config->bNumInterfaces && !found; ++i)
            for (j = 0; j < (unsigned int)config->interface[i].num_altsetting && !found; ++j)
            {
                const struct libusb_interface_descriptor *alt = &config->interface[i].altsetting[j];
                if (alt->bInterfaceNumber != pipe->interface_number || alt->bAlternateSetting != pipe->alternate) continue;
                for (k = 0; k < alt->bNumEndpoints; ++k)
                {
                    const struct libusb_endpoint_descriptor *endpoint = &alt->endpoint[k];
                    USBD_PIPE_TYPE type;
                    switch (endpoint->bmAttributes & LIBUSB_TRANSFER_TYPE_MASK)
                    {
                        case LIBUSB_TRANSFER_TYPE_BULK: type = UsbdPipeTypeBulk; break;
                        case LIBUSB_TRANSFER_TYPE_INTERRUPT: type = UsbdPipeTypeInterrupt; break;
                        default: continue;
                    }
                    if (endpoint->bEndpointAddress == pipe->endpoint && type == pipe->type) { found = true; break; }
                }
            }
        libusb_free_config_descriptor(device->function ? NULL : config);
        if (!found) return false;
    }
    return device_has_interface(device, pipe->interface_number) &&
            (!device->function || interface_in_set(device->claimed_interfaces,
            pipe->interface_number)) && device->pipe_table &&
            device->pipe_table->alternates[pipe->interface_number] == pipe->alternate;
}

static bool control_endpoint_is_current(const struct unix_device *device, uint8_t endpoint)
{
    unsigned int i;

    if (!device->pipe_table) return false;
    for (i = 0; i < WINEUSB_PIPE_TOKEN_SLOTS; ++i)
    {
        const struct wineusb_pipe_token *pipe = &device->pipe_table->records[i];

        if (pipe->current && pipe->endpoint == endpoint && pipe_token_is_current(device, pipe))
            return true;
    }
    return false;
}

static struct wineusb_pipe_table *copy_pipe_table(const struct unix_device *device)
{
    struct wineusb_pipe_table *table = calloc(1, sizeof(*table));
    if (table && device->pipe_table) *table = *device->pipe_table;
    return table;
}

/* Do not let a URB invent pipe metadata.  The active descriptor is the sole
 * authority for the interface/alternate and every returned pipe field. */
static bool validate_active_interface(libusb_device_handle *handle,
        const USBD_INTERFACE_INFORMATION *interface)
{
    struct libusb_config_descriptor *config;
    const struct libusb_interface_descriptor *alt = NULL;
    unsigned int i, j;

    if (libusb_get_active_config_descriptor(libusb_get_device(handle), &config)) return false;
    for (i = 0; i < config->bNumInterfaces && !alt; ++i)
        for (j = 0; j < (unsigned int)config->interface[i].num_altsetting; ++j)
        {
            const struct libusb_interface_descriptor *candidate = &config->interface[i].altsetting[j];
            if (candidate->bInterfaceNumber == interface->InterfaceNumber &&
                    candidate->bAlternateSetting == interface->AlternateSetting)
            { alt = candidate; break; }
        }
    if (!alt || alt->bNumEndpoints != interface->NumberOfPipes ||
            alt->bInterfaceClass != interface->Class ||
            alt->bInterfaceSubClass != interface->SubClass ||
            alt->bInterfaceProtocol != interface->Protocol)
    { libusb_free_config_descriptor(config); return false; }
    for (i = 0; i < interface->NumberOfPipes; ++i)
    {
        const USBD_PIPE_INFORMATION *pipe = &interface->Pipes[i];
        const struct libusb_endpoint_descriptor *endpoint = &alt->endpoint[i];
        USBD_PIPE_TYPE type;
        switch (endpoint->bmAttributes & LIBUSB_TRANSFER_TYPE_MASK)
        {
            case LIBUSB_TRANSFER_TYPE_BULK: type = UsbdPipeTypeBulk; break;
            case LIBUSB_TRANSFER_TYPE_INTERRUPT: type = UsbdPipeTypeInterrupt; break;
            default: libusb_free_config_descriptor(config); return false;
        }
        if (pipe->EndpointAddress != endpoint->bEndpointAddress || pipe->PipeType != type ||
                pipe->MaximumPacketSize != endpoint->wMaxPacketSize ||
                pipe->Interval != endpoint->bInterval)
        { libusb_free_config_descriptor(config); return false; }
    }
    libusb_free_config_descriptor(config);
    return true;
}

static NTSTATUS validate_select_configuration(const struct unix_device *device, IRP *irp,
        struct _URB_SELECT_CONFIGURATION *req, unsigned int *interface_count,
        unsigned int *pipe_count)
{
    const size_t request_header_size = offsetof(struct _URB_SELECT_CONFIGURATION, Interface);
    const size_t interface_header_size = offsetof(USBD_INTERFACE_INFORMATION, Pipes);
    const unsigned char *cursor, *end;
    unsigned int interfaces = 0, pipes = 0;
    const char *reason = "unknown";
    size_t available = 0, required = 0;
    ULONG declared_pipes = 0;

    if (req->Hdr.Length < request_header_size)
    {
        reason = "short_request_header";
        available = req->Hdr.Length;
        required = request_header_size;
        goto invalid;
    }

    cursor = (const unsigned char *)&req->Interface;
    end = (const unsigned char *)req + req->Hdr.Length;
    while (cursor < end)
    {
        const USBD_INTERFACE_INFORMATION *interface;
        size_t remaining, available_pipes;

        remaining = end - cursor;
        if (remaining < interface_header_size)
        {
            reason = "short_interface_header";
            available = remaining;
            required = interface_header_size;
            goto invalid;
        }

        interface = (const USBD_INTERFACE_INFORMATION *)cursor;
        if (interface->Length < interface_header_size)
        {
            reason = "short_interface_length";
            available = interface->Length;
            required = interface_header_size;
            goto invalid;
        }
        if (interface->Length > remaining)
        {
            reason = "interface_length_exceeds_request";
            available = remaining;
            required = interface->Length;
            goto invalid;
        }
        if (interface->Length != interface_header_size + interface->NumberOfPipes * sizeof(interface->Pipes[0]))
        {
            reason = "non_exact_interface_length";
            available = interface->Length;
            required = interface_header_size + interface->NumberOfPipes * sizeof(interface->Pipes[0]);
            goto invalid;
        }
        if (!device_has_interface(device, interface->InterfaceNumber))
        {
            reason = "interface_out_of_scope";
            available = interface->InterfaceNumber;
            required = 0;
            goto invalid;
        }

        /* The request is only a proposed map.  Never mint a token from its
         * metadata unless the active configuration agrees exactly. */
        if (!validate_active_interface(device->handle, interface))
        {
            reason = "active_descriptor_mismatch";
            available = interface->InterfaceNumber;
            required = interface->AlternateSetting;
            goto invalid;
        }

        available_pipes = (interface->Length - interface_header_size) /
                sizeof(interface->Pipes[0]);
        if (interface->NumberOfPipes > available_pipes)
        {
            reason = "truncated_pipe_array";
            available = available_pipes;
            required = interface->NumberOfPipes;
            declared_pipes = interface->NumberOfPipes;
            goto invalid;
        }

        pipes += interface->NumberOfPipes;
        ++interfaces;
        cursor += interface->Length;
    }

    *interface_count = interfaces;
    *pipe_count = pipes;
    FIXME("IO24_HANDLE_POPULATION event=validated irp=%p header_length=%u "
            "interfaces=%u pipes=%u.\n", irp, req->Hdr.Length, interfaces, pipes);
    return STATUS_SUCCESS;

invalid:
    FIXME("IO24_HANDLE_POPULATION event=reject irp=%p reason=%s interface_index=%u "
            "available=%lu required=%lu declared_pipes=%u.\n", irp, reason,
            interfaces, (unsigned long)available, (unsigned long)required,
            (unsigned int)declared_pipes);
    req->Hdr.Status = USBD_STATUS_INVALID_PARAMETER;
    return STATUS_INVALID_PARAMETER;
}

static const unsigned char io24_clock_source_range[] =
{
    0x04, 0x00,
    0x44, 0xac, 0x00, 0x00, 0x44, 0xac, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x80, 0xbb, 0x00, 0x00, 0x80, 0xbb, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x88, 0x58, 0x01, 0x00, 0x88, 0x58, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x77, 0x01, 0x00, 0x00, 0x77, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00,
};

static bool wineusb_io24_control_range_supported(
        const struct _URB_CONTROL_TRANSFER *req)
{
    struct _URB_CONTROL_VENDOR_OR_CLASS_REQUEST canonical = {0};

    canonical.Hdr.Length = sizeof(canonical);
    canonical.Hdr.Function = URB_FUNCTION_CLASS_INTERFACE;
    canonical.TransferFlags = req->SetupPacket[0] ==
            (LIBUSB_REQUEST_TYPE_CLASS | LIBUSB_RECIPIENT_INTERFACE |
            LIBUSB_ENDPOINT_IN) ? WINEUSB_IO24_CLASS_INTERFACE_FLAGS : 0;
    canonical.TransferBufferLength = req->TransferBufferLength;
    canonical.Request = req->SetupPacket[1];
    canonical.Value = req->SetupPacket[2] | (req->SetupPacket[3] << 8);
    canonical.Index = req->SetupPacket[4] | (req->SetupPacket[5] << 8);
    return wineusb_io24_class_interface_in_supported(&canonical);
}

static NTSTATUS complete_io24_clock_source_range(struct _URB_HEADER *header,
        ULONG *length, void *buffer)
{
    memcpy(buffer, io24_clock_source_range, sizeof(io24_clock_source_range));
    *length = sizeof(io24_clock_source_range);
    header->Status = USBD_STATUS_SUCCESS;
    return STATUS_SUCCESS;
}

static NTSTATUS usb_submit_urb(void *args)
{
    const struct usb_submit_urb_params *params = args;
    IRP *irp = params->irp;

    URB *urb = IoGetCurrentIrpStackLocation(irp)->Parameters.Others.Argument1;
    libusb_device_handle *handle = params->device->handle;
    struct libusb_transfer *transfer;
    int ret;

    TRACE("type %#x.\n", urb->UrbHeader.Function);

    switch (urb->UrbHeader.Function)
    {
        case URB_FUNCTION_SELECT_INTERFACE:
        {
            struct _URB_SELECT_INTERFACE *req = &urb->UrbSelectInterface;
            USBD_INTERFACE_INFORMATION *interface = &req->Interface;
            size_t header = offsetof(struct _URB_SELECT_INTERFACE, Interface);
            size_t interface_header = offsetof(USBD_INTERFACE_INFORMATION, Pipes);
            struct wineusb_pipe_table *table;
            HANDLE handles[WINEUSB_PIPE_TOKEN_SLOTS];
            ULONG i; uint32_t generation;
            if (req->Hdr.Length < header + interface_header || req->Hdr.Length != header + interface->Length ||
                    interface->Length < interface_header || interface->Length != interface_header +
                    interface->NumberOfPipes * sizeof(interface->Pipes[0]) ||
                    !device_has_interface(params->device, interface->InterfaceNumber) ||
                    (params->device->function && !interface_in_set(params->device->claimed_interfaces, interface->InterfaceNumber)) ||
                    interface->NumberOfPipes > WINEUSB_PIPE_TOKEN_SLOTS ||
                    !validate_active_interface(handle, interface))
            { req->Hdr.Status = USBD_STATUS_INVALID_PARAMETER; return STATUS_INVALID_PARAMETER; }

            if (!(table = copy_pipe_table(params->device)))
            { req->Hdr.Status = USBD_STATUS_REQUEST_FAILED; return STATUS_NO_MEMORY; }
            /* Replacing an alternate retires only this interface's current
             * records.  Allocate every replacement before touching libusb. */
            for (i = 0; i < WINEUSB_PIPE_TOKEN_SLOTS; ++i)
                if (table->records[i].current && table->records[i].interface_number == interface->InterfaceNumber)
                    table->records[i].current = false;
            generation = table->next_generation ? table->next_generation : 1;
            if (generation > WINEUSB_PIPE_TOKEN_GENERATION_MAX)
            { free(table); req->Hdr.Status = USBD_STATUS_REQUEST_FAILED; return STATUS_INSUFFICIENT_RESOURCES; }
            for (i = 0; i < interface->NumberOfPipes; ++i)
            {
                if (!interface->Pipes[i].EndpointAddress ||
                        (interface->Pipes[i].PipeType != UsbdPipeTypeBulk &&
                         interface->Pipes[i].PipeType != UsbdPipeTypeInterrupt) ||
                        !(handles[i] = issue_pipe_token(table, interface->Pipes[i].EndpointAddress,
                        interface->Pipes[i].PipeType, interface->InterfaceNumber,
                        interface->AlternateSetting, generation)))
                {
                    free(table);
                    req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                    return STATUS_INSUFFICIENT_RESOURCES;
                }
            }
            if ((ret = libusb_set_interface_alt_setting(handle, interface->InterfaceNumber, interface->AlternateSetting)) < 0)
            { free(table); req->Hdr.Status = USBD_STATUS_REQUEST_FAILED; return STATUS_UNSUCCESSFUL; }
            for (i = 0; i < interface->NumberOfPipes; ++i)
                interface->Pipes[i].PipeHandle = handles[i];
            table->alternates[interface->InterfaceNumber] = interface->AlternateSetting;
            table->next_generation = generation + 1; /* terminal after max; never wrap */
            free(params->device->pipe_table);
            params->device->pipe_table = table;
            req->Hdr.Status = USBD_STATUS_SUCCESS;
            return STATUS_SUCCESS;
        }

        case URB_FUNCTION_SYNC_RESET_PIPE_AND_CLEAR_STALL:
        {
            struct _URB_PIPE_REQUEST *req = &urb->UrbPipeRequest;
            struct wineusb_pipe_token *pipe = lookup_pipe_token(params->device, req->PipeHandle);

            if (!pipe || !pipe_token_is_current(params->device, pipe)) { req->Hdr.Status = USBD_STATUS_INVALID_PIPE_HANDLE; return STATUS_INVALID_PARAMETER; }

            if ((ret = libusb_clear_halt(handle, pipe->endpoint)) < 0)
                ERR("Failed to clear halt: %s\n", libusb_strerror(ret));
            FIXME("IO24_PIPE_OBSERVE event=clear_halt irp=%p handle=%p endpoint=%#x "
                    "type=%u libusb_status=%d returned_status=%#x.\n", irp,
                    req->PipeHandle, pipe->endpoint, pipe->type, ret,
                    (unsigned int)STATUS_SUCCESS);

            return STATUS_SUCCESS;
        }

        case URB_FUNCTION_BULK_OR_INTERRUPT_TRANSFER:
        {
            struct _URB_BULK_OR_INTERRUPT_TRANSFER *req = &urb->UrbBulkOrInterruptTransfer;
            struct wineusb_pipe_token *pipe = lookup_pipe_token(params->device, req->PipeHandle);
            struct transfer_ctx *transfer_ctx;
            NTSTATUS status = STATUS_PENDING;
            const char *route = pipe && pipe->type == UsbdPipeTypeBulk ? "bulk" :
                    pipe && pipe->type == UsbdPipeTypeInterrupt ? "interrupt" : "invalid";

            if (!pipe || !pipe_token_is_current(params->device, pipe)) { req->Hdr.Status = USBD_STATUS_INVALID_PIPE_HANDLE; return STATUS_INVALID_PARAMETER; }

            if (req->TransferBufferLength && !params->transfer_buffer)
            {
                req->Hdr.Status = USBD_STATUS_INVALID_PARAMETER;
                FIXME("IO24_PIPE_SAFETY event=transfer_reject reason=null_buffer irp=%p "
                        "handle=%p endpoint=%#x type=%u route=%s length=%u.\n", irp,
                        req->PipeHandle, pipe->endpoint, pipe->type, route,
                        req->TransferBufferLength);
                return STATUS_INVALID_PARAMETER;
            }

            FIXME("IO24_PIPE_OBSERVE event=transfer_route irp=%p handle=%p endpoint=%#x "
                    "type=%u route=%s length=%u buffer=%p.\n", irp, req->PipeHandle,
                    pipe->endpoint, pipe->type, route, req->TransferBufferLength,
                    params->transfer_buffer);

            if (!(transfer_ctx = calloc(1, sizeof(*transfer_ctx))))
                return STATUS_NO_MEMORY;
            transfer_ctx->irp = irp;
            transfer_ctx->transfer_buffer = params->transfer_buffer;
            transfer_ctx->transfer_buffer_length = req->TransferBufferLength;

            if (!(transfer = libusb_alloc_transfer(0)))
            {
                free(transfer_ctx);
                return STATUS_NO_MEMORY;
            }
            irp->Tail.Overlay.DriverContext[0] = transfer;

            if (pipe->type == UsbdPipeTypeBulk)
            {
                libusb_fill_bulk_transfer(transfer, handle, pipe->endpoint,
                        params->transfer_buffer, req->TransferBufferLength, transfer_cb, transfer_ctx, 0);
            }
            else if (pipe->type == UsbdPipeTypeInterrupt)
            {
                libusb_fill_interrupt_transfer(transfer, handle, pipe->endpoint,
                        params->transfer_buffer, req->TransferBufferLength, transfer_cb, transfer_ctx, 0);
            }
            else
            {
                WARN("Invalid pipe type %#x.\n", pipe->type);
                irp->Tail.Overlay.DriverContext[0] = NULL;
                free(transfer_ctx);
                libusb_free_transfer(transfer);
                return USBD_STATUS_INVALID_PIPE_HANDLE;
            }

            transfer->flags = LIBUSB_TRANSFER_FREE_TRANSFER;
            ret = libusb_submit_transfer(transfer);
            if (ret < 0)
            {
                ERR("Failed to submit bulk transfer: %s\n", libusb_strerror(ret));
                irp->Tail.Overlay.DriverContext[0] = NULL;
                req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                libusb_free_transfer(transfer);
                free(transfer_ctx);
                status = STATUS_UNSUCCESSFUL;
            }
            FIXME("IO24_PIPE_OBSERVE event=transfer_submit irp=%p handle=%p endpoint=%#x "
                    "route=%s length=%u buffer=%p libusb_status=%d returned_status=%#x.\n",
                    irp, req->PipeHandle, pipe->endpoint, route, req->TransferBufferLength,
                    params->transfer_buffer, ret, (unsigned int)status);

            return status;
        }

        case URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE:
        {
            struct _URB_CONTROL_DESCRIPTOR_REQUEST *req = &urb->UrbControlDescriptorRequest;
            struct transfer_ctx *transfer_ctx;
            unsigned char *buffer;
            size_t transfer_length = req->TransferBufferLength;

            if (!(transfer_ctx = calloc(1, sizeof(*transfer_ctx))))
                return STATUS_NO_MEMORY;
            transfer_ctx->irp = irp;
            transfer_ctx->transfer_buffer = params->transfer_buffer;
            transfer_ctx->transfer_buffer_length = req->TransferBufferLength;
            transfer_ctx->function = params->device->function;
            transfer_ctx->function_interface_count = params->device->function_interface_count;
            transfer_ctx->function_root = params->device->function_root;
            memcpy(transfer_ctx->function_interfaces, params->device->function_interfaces,
                    sizeof(transfer_ctx->function_interfaces));

            if (params->device->function && req->DescriptorType == LIBUSB_DT_CONFIG &&
                    transfer_length < params->device->configuration_length)
                transfer_length = params->device->configuration_length;

            if (!(transfer = libusb_alloc_transfer(0)))
            {
                free(transfer_ctx);
                return STATUS_NO_MEMORY;
            }
            irp->Tail.Overlay.DriverContext[0] = transfer;

            if (!(buffer = malloc(sizeof(struct libusb_control_setup) + transfer_length)))
            {
                irp->Tail.Overlay.DriverContext[0] = NULL;
                free(transfer_ctx);
                libusb_free_transfer(transfer);
                return STATUS_NO_MEMORY;
            }

            libusb_fill_control_setup(buffer,
                    LIBUSB_ENDPOINT_IN | LIBUSB_REQUEST_TYPE_STANDARD | LIBUSB_RECIPIENT_DEVICE,
                    LIBUSB_REQUEST_GET_DESCRIPTOR, (req->DescriptorType << 8) | req->Index,
                    req->LanguageId, transfer_length);
            libusb_fill_control_transfer(transfer, handle, buffer, transfer_cb, transfer_ctx, 0);
            transfer->flags = LIBUSB_TRANSFER_FREE_BUFFER | LIBUSB_TRANSFER_FREE_TRANSFER;
            ret = libusb_submit_transfer(transfer);
            if (ret < 0)
            {
                ERR("Failed to submit GET_DESCRIPTOR transfer: %s\n", libusb_strerror(ret));
                irp->Tail.Overlay.DriverContext[0] = NULL;
                req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                libusb_free_transfer(transfer);
                free(transfer_ctx);
                return STATUS_UNSUCCESSFUL;
            }

            return STATUS_PENDING;
        }

        case URB_FUNCTION_CONTROL_TRANSFER:
        {
            struct _URB_CONTROL_TRANSFER *req = &urb->UrbControlTransfer;
            uint8_t request_type = req->SetupPacket[0];
            uint8_t recipient = request_type & 0x1f;
            uint8_t type = request_type & 0x60;
            uint16_t length = req->SetupPacket[6] | (req->SetupPacket[7] << 8);
            bool range_supported;
            struct transfer_ctx *transfer_ctx;
            unsigned char *buffer;

            if (req->Hdr.Length != sizeof(*req) || length != req->TransferBufferLength ||
                    length > WINE_WINUSB_MAX_CONTROL_TRANSFER || (length && !params->transfer_buffer) ||
                    (type != LIBUSB_REQUEST_TYPE_STANDARD && type != LIBUSB_REQUEST_TYPE_CLASS &&
                    type != LIBUSB_REQUEST_TYPE_VENDOR) || recipient > LIBUSB_RECIPIENT_OTHER ||
                    (recipient == LIBUSB_RECIPIENT_ENDPOINT &&
                    (!control_endpoint_is_current(params->device, req->SetupPacket[4]) ||
                    ((req->SetupPacket[4] ^ request_type) & LIBUSB_ENDPOINT_IN))))
            {
                req->Hdr.Status = USBD_STATUS_INVALID_PARAMETER;
                return STATUS_INVALID_PARAMETER;
            }
            range_supported = wineusb_io24_control_range_supported(req);
            if (recipient == LIBUSB_RECIPIENT_INTERFACE && !range_supported &&
                    !device_has_interface(params->device, req->SetupPacket[4]))
            {
                req->Hdr.Status = USBD_STATUS_INVALID_PARAMETER;
                return STATUS_INVALID_PARAMETER;
            }
            if (range_supported)
                return complete_io24_clock_source_range(&req->Hdr,
                        &req->TransferBufferLength, params->transfer_buffer);

            if (!(transfer_ctx = calloc(1, sizeof(*transfer_ctx))))
            {
                req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                return STATUS_NO_MEMORY;
            }
            transfer_ctx->irp = irp;
            transfer_ctx->transfer_buffer = params->transfer_buffer;
            transfer_ctx->transfer_buffer_length = length;
            if (!(transfer = libusb_alloc_transfer(0)))
            {
                free(transfer_ctx);
                req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                return STATUS_NO_MEMORY;
            }
            irp->Tail.Overlay.DriverContext[0] = transfer;
            if (!(buffer = malloc(sizeof(struct libusb_control_setup) + length)))
            {
                irp->Tail.Overlay.DriverContext[0] = NULL;
                free(transfer_ctx);
                libusb_free_transfer(transfer);
                req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                return STATUS_NO_MEMORY;
            }
            libusb_fill_control_setup(buffer, request_type, req->SetupPacket[1],
                    req->SetupPacket[2] | (req->SetupPacket[3] << 8),
                    req->SetupPacket[4] | (req->SetupPacket[5] << 8), length);
            if (!(request_type & LIBUSB_ENDPOINT_IN))
                memcpy(buffer + LIBUSB_CONTROL_SETUP_SIZE, params->transfer_buffer, length);
            else memset(buffer + LIBUSB_CONTROL_SETUP_SIZE, 0xde, length);
            libusb_fill_control_transfer(transfer, handle, buffer, transfer_cb, transfer_ctx, 5000);
            transfer->flags = LIBUSB_TRANSFER_FREE_BUFFER | LIBUSB_TRANSFER_FREE_TRANSFER;
            ret = libusb_submit_transfer(transfer);
            if (ret < 0)
            {
                irp->Tail.Overlay.DriverContext[0] = NULL;
                req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                libusb_free_transfer(transfer);
                free(transfer_ctx);
                return STATUS_UNSUCCESSFUL;
            }
            return STATUS_PENDING;
        }

        case URB_FUNCTION_SELECT_CONFIGURATION:
        {
            struct _URB_SELECT_CONFIGURATION *req = &urb->UrbSelectConfiguration;
            unsigned char *cursor, *end;
            unsigned char required_interfaces[32] = {0};
            unsigned int interface_count, pipe_count;
            struct claim_transaction *transaction = NULL;
            struct wineusb_pipe_table *table;
            HANDLE handles[WINEUSB_PIPE_TOKEN_SLOTS];
            NTSTATUS status;
            unsigned int interface_number; uint32_t generation;

            /* FIXME: In theory, we'd call libusb_set_configuration() here, but
             * the CASIO FX-9750GII (which has only one configuration) goes into
             * an error state if it receives a SET_CONFIGURATION request. Maybe
             * we should skip setting that if and only if the configuration is
             * already active? */

            if (params->device->function && params->device->pending_claim_transaction)
            {
                req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                return STATUS_INVALID_DEVICE_STATE;
            }

            status = validate_select_configuration(params->device, irp, req,
                    &interface_count, &pipe_count);
            if (status != STATUS_SUCCESS)
                return status;

            /* Form a complete future table before claiming anything.  Tokens
             * are published only by COMMIT for a function child. */
            if (!(table = params->device->function ?
                    copy_pipe_table(params->device) : calloc(1, sizeof(*table))))
            {
                req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                return STATUS_NO_MEMORY;
            }
            if (!params->device->function && params->device->pipe_table)
                table->next_generation = params->device->pipe_table->next_generation;
            generation = table->next_generation ? table->next_generation : 1;
            if (generation > WINEUSB_PIPE_TOKEN_GENERATION_MAX || pipe_count > WINEUSB_PIPE_TOKEN_SLOTS)
            { free(table); req->Hdr.Status = USBD_STATUS_REQUEST_FAILED; return STATUS_INSUFFICIENT_RESOURCES; }

            /* Build the whole future map before acquiring a single interface.
             * In particular, no failure below this point may leave a caller
             * ConfigurationHandle or PipeHandle referring to freed staging. */
            cursor = (unsigned char *)&req->Interface;
            end = (unsigned char *)req + req->Hdr.Length;
            if (params->device->function)
            {
                /* A function SELECT_CONFIGURATION may extend an existing
                 * committed claim set.  Preserve every committed record not
                 * named by this transaction, and retire only the interfaces
                 * whose replacement records are staged below. */
                while (cursor < end)
                {
                    USBD_INTERFACE_INFORMATION *interface = (void *)cursor;
                    unsigned int slot;

                    for (slot = 0; slot < WINEUSB_PIPE_TOKEN_SLOTS; ++slot)
                        if (table->records[slot].current &&
                                table->records[slot].interface_number ==
                                interface->InterfaceNumber)
                            table->records[slot].current = false;
                    cursor += interface->Length;
                }
                cursor = (unsigned char *)&req->Interface;
            }
            pipe_count = 0;
            while (cursor < end)
            {
                USBD_INTERFACE_INFORMATION *interface = (void *)cursor;
                ULONG i;

                for (i = 0; i < interface->NumberOfPipes; ++i)
                {
                    USBD_PIPE_INFORMATION *pipe = &interface->Pipes[i];

                    if (!(handles[pipe_count] = issue_pipe_token(table,
                            pipe->EndpointAddress, pipe->PipeType,
                            interface->InterfaceNumber, interface->AlternateSetting,
                            generation)))
                    {
                        free(table);
                        req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                        return STATUS_INSUFFICIENT_RESOURCES;
                    }
                    ++pipe_count;
                }
                table->alternates[interface->InterfaceNumber] = interface->AlternateSetting;
                cursor += interface->Length;
            }
            table->next_generation = generation + 1; /* max succeeds once */

            if (params->device->function)
            {
                cursor = (unsigned char *)&req->Interface;
                end = (unsigned char *)req + req->Hdr.Length;
                while (cursor < end)
                {
                    USBD_INTERFACE_INFORMATION *interface = (void *)cursor;
                    add_interface_to_set(required_interfaces,
                            interface->InterfaceNumber);
                    cursor += interface->Length;
                }

                if (!(transaction = calloc(1, sizeof(*transaction))))
                {
                    free(table);
                    req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                    return STATUS_NO_MEMORY;
                }
                transaction->token = allocate_claim_transaction_token();
                transaction->pipe_table = table;
                for (interface_number = 0; interface_number < 256; ++interface_number)
                {
                    int claim_status;

                    if (!interface_in_set(required_interfaces, interface_number) ||
                            interface_in_set(params->device->claimed_interfaces,
                            interface_number))
                        continue;
                    if ((claim_status = libusb_claim_interface(handle,
                            interface_number)) < 0)
                    {
                        release_claim_transaction(params->device, transaction);
                        free(transaction->pipe_table);
                        free(transaction);
                        req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                        return claim_status == LIBUSB_ERROR_BUSY ? STATUS_DEVICE_BUSY :
                                STATUS_UNSUCCESSFUL;
                    }
                    transaction->interfaces[transaction->count++] = interface_number;
                }
                params->device->pending_claim_transaction = transaction;
                req->ConfigurationHandle = transaction->token;
            }

            FIXME("IO24_PIPE_OBSERVE event=select_configuration_backend irp=%p "
                    "scope=%s root=%u interfaces=%u pipes=%u.\n", irp,
                    params->device->function ? "function" : "all_interfaces",
                    params->device->function ? params->device->function_root : 0,
                    interface_count, pipe_count);

            if (!transaction)
            {
                free(params->device->pipe_table);
                params->device->pipe_table = table;
            }

            cursor = (unsigned char *)&req->Interface;
            end = (unsigned char *)req + req->Hdr.Length;
            pipe_count = 0;
            while (cursor < end)
            {
                USBD_INTERFACE_INFORMATION *interface = (void *)cursor;
                ULONG i;
                for (i = 0; i < interface->NumberOfPipes; ++i)
                    interface->Pipes[i].PipeHandle = handles[pipe_count++];
                cursor += interface->Length;
            }

            FIXME("IO24_HANDLE_POPULATION event=populated irp=%p interfaces=%u pipes=%u.\n",
                    irp, interface_count, pipe_count);

            req->Hdr.Status = USBD_STATUS_SUCCESS;
            return STATUS_SUCCESS;
        }

        case WINEUSB_URB_FUNCTION_CLAIM_TRANSACTION:
        {
            struct wineusb_claim_transaction_request *req =
                    (struct wineusb_claim_transaction_request *)urb;
            struct claim_transaction *transaction =
                    params->device->pending_claim_transaction;
            unsigned int i;

            if (!params->device->function || req->Hdr.Length != sizeof(*req) ||
                    !req->Transaction || req->Reserved ||
                    (req->Operation != WINEUSB_CLAIM_TRANSACTION_COMMIT &&
                    req->Operation != WINEUSB_CLAIM_TRANSACTION_ROLLBACK) ||
                    !transaction || transaction->token != req->Transaction)
            {
                req->Hdr.Status = USBD_STATUS_INVALID_PARAMETER;
                return STATUS_INVALID_PARAMETER;
            }

            params->device->pending_claim_transaction = NULL;
            if (req->Operation == WINEUSB_CLAIM_TRANSACTION_COMMIT)
            {
                for (i = 0; i < transaction->count; ++i)
                    add_interface_to_set(params->device->claimed_interfaces,
                            transaction->interfaces[i]);
                free(params->device->pipe_table);
                params->device->pipe_table = transaction->pipe_table;
                transaction->pipe_table = NULL;
            }
            else release_claim_transaction(params->device, transaction);
            free(transaction->pipe_table);
            free(transaction);
            req->Hdr.Status = USBD_STATUS_SUCCESS;
            return STATUS_SUCCESS;
        }

        case URB_FUNCTION_CLASS_INTERFACE:
        {
            struct _URB_CONTROL_VENDOR_OR_CLASS_REQUEST *req = &urb->UrbControlVendorClassRequest;

            if (req->Hdr.Length < sizeof(*req))
            {
                req->Hdr.Status = USBD_STATUS_INVALID_PARAMETER;
                return STATUS_INVALID_PARAMETER;
            }
            if (!wineusb_io24_class_interface_in_supported(req))
            {
                req->Hdr.Status = USBD_STATUS_NOT_SUPPORTED;
                return STATUS_NOT_SUPPORTED;
            }
            if (!params->transfer_buffer)
            {
                req->Hdr.Status = USBD_STATUS_INVALID_PARAMETER;
                return STATUS_INVALID_PARAMETER;
            }

            TRACE("IO24_CLASS_IN captured RANGE response length %u.\n",
                    (unsigned int)sizeof(io24_clock_source_range));
            irp->Tail.Overlay.DriverContext[0] = NULL;
            return complete_io24_clock_source_range(&req->Hdr,
                    &req->TransferBufferLength, params->transfer_buffer);
        }

        case URB_FUNCTION_VENDOR_DEVICE:
        case URB_FUNCTION_VENDOR_INTERFACE:
        case URB_FUNCTION_VENDOR_ENDPOINT:
        {
            struct _URB_CONTROL_VENDOR_OR_CLASS_REQUEST *req = &urb->UrbControlVendorClassRequest;
            uint8_t req_type = LIBUSB_REQUEST_TYPE_VENDOR;
            struct transfer_ctx *transfer_ctx;
            unsigned char *buffer;

            if (!(transfer_ctx = calloc(1, sizeof(*transfer_ctx))))
                return STATUS_NO_MEMORY;
            transfer_ctx->irp = irp;
            transfer_ctx->transfer_buffer = params->transfer_buffer;
            transfer_ctx->transfer_buffer_length = req->TransferBufferLength;

            if (urb->UrbHeader.Function == URB_FUNCTION_VENDOR_DEVICE)
                req_type |= LIBUSB_RECIPIENT_DEVICE;
            else if (urb->UrbHeader.Function == URB_FUNCTION_VENDOR_INTERFACE)
                req_type |= LIBUSB_RECIPIENT_INTERFACE;
            else
                req_type |= LIBUSB_RECIPIENT_ENDPOINT;

            if (req->TransferFlags & USBD_TRANSFER_DIRECTION_IN)
                req_type |= LIBUSB_ENDPOINT_IN;
            if (req->TransferFlags & ~USBD_TRANSFER_DIRECTION_IN)
                FIXME("Unhandled flags %#x.\n", (int)req->TransferFlags);

            if (!(transfer = libusb_alloc_transfer(0)))
            {
                free(transfer_ctx);
                return STATUS_NO_MEMORY;
            }
            irp->Tail.Overlay.DriverContext[0] = transfer;

            if (!(buffer = malloc(sizeof(struct libusb_control_setup) + req->TransferBufferLength)))
            {
                irp->Tail.Overlay.DriverContext[0] = NULL;
                free(transfer_ctx);
                libusb_free_transfer(transfer);
                return STATUS_NO_MEMORY;
            }

            libusb_fill_control_setup(buffer, req_type, req->Request,
                    req->Value, req->Index, req->TransferBufferLength);
            if (!(req->TransferFlags & USBD_TRANSFER_DIRECTION_IN))
                memcpy(buffer + LIBUSB_CONTROL_SETUP_SIZE, params->transfer_buffer, req->TransferBufferLength);
            libusb_fill_control_transfer(transfer, handle, buffer, transfer_cb, transfer_ctx, 0);
            transfer->flags = LIBUSB_TRANSFER_FREE_BUFFER | LIBUSB_TRANSFER_FREE_TRANSFER;
            ret = libusb_submit_transfer(transfer);
            if (ret < 0)
            {
                ERR("Failed to submit vendor-specific interface transfer: %s\n", libusb_strerror(ret));
                irp->Tail.Overlay.DriverContext[0] = NULL;
                req->Hdr.Status = USBD_STATUS_REQUEST_FAILED;
                libusb_free_transfer(transfer);
                free(transfer_ctx);
                return STATUS_UNSUCCESSFUL;
            }

            return STATUS_PENDING;
        }

        default:
            FIXME("Unhandled function %#x.\n", urb->UrbHeader.Function);
    }

    return STATUS_NOT_IMPLEMENTED;
}

static NTSTATUS usb_cancel_transfer(void *args)
{
    const struct usb_cancel_transfer_params *params = args;
    int ret;

    if ((ret = libusb_cancel_transfer(params->transfer)) < 0)
        ERR("Failed to cancel transfer: %s\n", libusb_strerror(ret));

    return STATUS_SUCCESS;
}

static void decref_device(struct unix_device *device)
{
    pthread_mutex_lock(&device_mutex);

    if (--device->refcount)
    {
        pthread_mutex_unlock(&device_mutex);
        return;
    }

    list_remove(&device->entry);

    pthread_mutex_unlock(&device_mutex);

    if (device->pending_claim_transaction)
    {
        release_claim_transaction(device, device->pending_claim_transaction);
        free(device->pending_claim_transaction->pipe_table);
        free(device->pending_claim_transaction);
        device->pending_claim_transaction = NULL;
    }
    free(device->pipe_table);
    device->pipe_table = NULL;
    if (device->function)
    {
        unsigned int interface;

        for (interface = 256; interface; --interface)
            if (interface_in_set(device->claimed_interfaces, interface - 1))
                libusb_release_interface(device->handle, interface - 1);
    }

    if (device->parent)
        decref_device(device->parent);
    else
        libusb_close(device->handle);
    free(device);
}

static NTSTATUS usb_destroy_device(void *args)
{
    const struct usb_destroy_device_params *params = args;
    struct unix_device *device = params->device;

    decref_device(device);

    return STATUS_SUCCESS;
}

const unixlib_entry_t __wine_unix_call_funcs[] =
{
#define X(name) [unix_ ## name] = name
    X(usb_main_loop),
    X(usb_init),
    X(usb_exit),
    X(usb_submit_urb),
    X(usb_cancel_transfer),
    X(usb_destroy_device),
};
