# Task 9 R149 isolated lifecycle-oracle evidence

Timestamp: 2026-08-28T15:40:04-07:00

This package records a test-only successor to rejected, unapplied R148. It does
not modify production. The direct proposal changes only the lower contract,
fake libusb boundary, and its wrapper.

The `tdd-red` tree proves that the two source-bound production mutants escape
R148: clean focused and retained controls exit 0, and all three mutant
executions also exit 0. The `final` tree proves that R149 keeps both clean
controls at exit 0 while classifying the same three mutant executions as
feature failures at exit 1 with nonzero assertion counts.

Every final row contains the exact mutated production source, its zero-fuzz
diff and deterministic recipe, the restored source, execution logs and exit
files, structured results, and independent hashes. Row 2 intentionally has no
fake pass marker because the one-shot early release triggers retained product
assertions; its normal lower summary and exit 1 distinguish that result from a
harness failure.

No Wine prefix, USB device, driver staging, network, firmware, preset, or
effect operation is part of this package.
