#!/usr/bin/env bash
set -uo pipefail

if (( $# != 5 )); then
    echo 'usage: r149_oracle_contract.sh CANDIDATE_TESTS SOURCE_TEMPLATE WINE_BUILD_ROOT LIBUSB_INCLUDE OUTPUT_DIR' >&2
    exit 2
fi

readonly candidate_tests=$(realpath -- "$1")
readonly source_template=$(realpath -- "$2")
readonly build_root=$(realpath -- "$3")
readonly libusb_include=$(realpath -- "$4")
readonly output_dir=$5
readonly script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)

for input in \
    "$candidate_tests/wineusb_winusb_urb_contract.c" \
    "$candidate_tests/wineusb_winusb_urb_fake_libusb.c" \
    "$candidate_tests/wineusb_winusb_urb_contract.sh" \
    "$candidate_tests/wineusb_pipe_observe_contract.c" \
    "$source_template/dlls/wineusb.sys/unixlib.c" \
    "$script_dir/01-same-address-table-release.patch" \
    "$script_dir/02-cached-nested-config-release.patch"
do
    [[ -f "$input" ]] || { echo "HARNESS: missing input: $input" >&2; exit 2; }
done

[[ -f "$build_root/dlls/ntdll/ntdll.so" ]] || { echo 'HARNESS: missing frozen ntdll' >&2; exit 2; }
[[ -f "$libusb_include/libusb.h" ]] || { echo 'HARNESS: missing frozen libusb header' >&2; exit 2; }
mkdir -p "$output_dir" || { echo 'HARNESS: cannot create output directory' >&2; exit 2; }

run_wrapper()
{
    local tests=$1 source=$2 mode=$3 log=$4 code
    timeout 30s nice -n 10 ionice -c 3 \
        "$tests/wineusb_winusb_urb_contract.sh" \
        "$source" "$build_root" "$libusb_include" "$mode" >"$log" 2>&1
    code=$?
    printf '%s\n' "$code" >"$log.exit"
    if (( code == 2 || code == 124 )) || grep -q 'HARNESS:' "$log"; then
        echo "HARNESS: invalid wrapper result mode=$mode exit=$code log=$log" >&2
        exit 2
    fi
    printf '%s' "$code"
}

require_clean()
{
    local name=$1 mode=$2 code log
    log="$output_dir/$name.log"
    code=$(run_wrapper "$candidate_tests" "$source_template" "$mode" "$log") || exit $?
    if (( code != 0 )) || ! grep -q 'failures=0' "$log"; then
        echo "ORACLE: clean control failed name=$name exit=$code" >&2
        return 1
    fi
}

prepare_case()
{
    local name=$1 patch_file=$2 case_root
    case_root="$output_dir/$name"
    mkdir -p "$case_root/source" "$case_root/tests" || exit 2
    cp -a "$source_template/." "$case_root/source/" || exit 2
    cp -a "$candidate_tests/." "$case_root/tests/" || exit 2
    patch --batch --fuzz=0 -p1 -d "$case_root/source" <"$patch_file" >"$case_root/patch.log" 2>&1 || {
        echo "HARNESS: zero-fuzz patch failed name=$name" >&2
        exit 2
    }
}

require_feature_red()
{
    local name=$1 mode=$2 case_root code log
    case_root="$output_dir/$name"
    log="$case_root/${mode#--}.log"
    code=$(run_wrapper "$case_root/tests" "$case_root/source" "$mode" "$log") || exit $?
    if (( code != 1 )) || ! grep -Eq 'failures=[1-9][0-9]*' "$log"; then
        echo "ORACLE: missed lifecycle regression name=$name mode=$mode exit=$code" >&2
        return 1
    fi
}

status=0
require_clean clean-focused --control-descriptor || status=1
require_clean clean-retained --red || status=1

prepare_case same-address-table-release "$script_dir/01-same-address-table-release.patch"
require_feature_red same-address-table-release --control-descriptor || status=1

prepare_case cached-nested-config-release "$script_dir/02-cached-nested-config-release.patch"
require_feature_red cached-nested-config-release --control-descriptor || status=1
require_feature_red cached-nested-config-release --red || status=1

if (( status )); then
    echo 'R149_ORACLE RED'
    exit 1
fi

echo 'R149_ORACLE PASS clean=2 regressions=3'
exit 0
